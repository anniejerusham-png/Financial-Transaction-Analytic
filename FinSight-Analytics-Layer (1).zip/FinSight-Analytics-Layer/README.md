# FinSight — Financial Transaction & Risk Analytics

**Portfolio project | SQL + Python + Interactive Dashboard**

FinSight analyzes a synthetic financial transaction dataset to demonstrate data cleaning, exploratory analysis, SQL analysis, risk indicators, and business-focused visualization.

## Business Questions
- How does transaction value change over time?
- Which merchant categories generate the most value?
- Which payment methods have the highest failure rates?
- Which cities contribute the most transaction activity?
- Which customer segments generate the most value?
- What percentage of transactions are flagged as suspicious?

## Technology
SQL · Python (Pandas, NumPy, Matplotlib) · HTML/CSS/JavaScript · Chart.js · Git/GitHub

## Project Structure
```text
FinSight/
├── data/
│   └── transactions.csv
├── sql/
│   └── analysis.sql
├── python/
│   └── EDA.ipynb
├── docs/
│   └── data_dictionary.md
└── index.html
```

## Dataset
100,000 synthetic transactions covering 2025. The data includes transaction dates, synthetic customers, customer segments, merchant categories, payment methods, cities, transaction values, transaction status, and a synthetic suspicious-activity indicator.

**No real customer, bank, card, or payment information is used.**

## Limitation
The suspicious-activity field is synthetic and is for educational portfolio analysis only. It is not a production fraud/AML model.
